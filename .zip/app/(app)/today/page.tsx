// export default function TodayPage() {
//   return <div className="p-6">Today Page</div>;
// }


"use client";

import { useAuth } from "@/lib/auth-context";
import { useGoals } from "@/hooks/useGoals";
import { useMilestones } from "@/hooks/useMilestones";
import { Button } from "@/components/ui/button";

export default function TodayPage() {
  const { user } = useAuth();

  const { goals } = useGoals(user?.uid || "");
  const { milestones } = useMilestones(user?.uid || "");

  const today = new Date().toISOString().split("T")[0];

  const todayTasks = milestones.filter((m: any) => {
    return m.startDate?.includes(today);
  });

  return (
    <div className="p-5 max-w-3xl mx-auto space-y-5">

      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-bold">🔥 Today</h1>
        <p className="text-xs text-muted-foreground">
          Only what matters today
        </p>
      </div>

      {/* TASK LIST */}
      <div className="space-y-3">

        {todayTasks.length === 0 && (
          <div className="text-center text-muted-foreground py-10">
            No tasks for today 🎯
          </div>
        )}

        {todayTasks.map((t: any) => (
          <div
            key={t.id}
            className="flex justify-between items-center p-4 border rounded-xl bg-background hover:shadow-sm"
          >

            {/* LEFT */}
            <div>
              <p className="font-medium">{t.name}</p>
              <p className="text-xs text-muted-foreground">
                Goal ID: {t.goalId}
              </p>
            </div>

            {/* ACTION */}
            <Button size="sm">
              Mark Done
            </Button>

          </div>
        ))}

      </div>

    </div>
  );
}