import { db } from "@/lib/firebase";
import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  deleteDoc,
  doc,
  updateDoc,
} from "firebase/firestore";

/* 🔥 PATH */
const col = (uid: string) =>
  collection(db, "users", uid, "milestones");

/* ================= CREATE ================= */
export const createMilestone = async (uid: string, data: any) => {
  if (!uid) throw new Error("UID missing");
  if (!data.goalId) throw new Error("goalId missing");

  return await addDoc(col(uid), {
    ...data,
    createdAt: new Date().toISOString(),
  });
};

/* ================= READ ================= */
export const getMilestonesByGoal = async (
  uid: string,
  goalId: string
) => {
  const q = query(col(uid), where("goalId", "==", goalId));
  const snap = await getDocs(q);

  return snap.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
};

/* ================= UPDATE ================= */
export const updateMilestone = async (
  uid: string,
  id: string,
  data: any
) => {
  return updateDoc(doc(db, "users", uid, "milestones", id), data);
};

/* ================= DELETE ================= */
export const deleteMilestone = async (uid: string, id: string) => {
  return deleteDoc(doc(db, "users", uid, "milestones", id));
};