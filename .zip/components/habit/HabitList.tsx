"use client";

import HabitCard from "./HabitCard";

export default function HabitList({ habits, onSelect }: any) {
  return (
    <div className="grid gap-4">
      {habits.map((h: any) => (
        <HabitCard
          key={h.id}
          habit={h}
          onClick={() => onSelect(h)}
        />
      ))}
    </div>
  );
}