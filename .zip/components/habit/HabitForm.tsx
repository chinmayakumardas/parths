"use client";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";

export default function HabitForm({
  form,
  setForm,
  onSubmit,
}: any) {
  return (
    <div className="space-y-5">

      <Input
        placeholder="Habit name"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <Input
        placeholder="Category (optional)"
        value={form.category}
        onChange={(e) =>
          setForm({ ...form, category: e.target.value })
        }
      />

      {/* FREQUENCY */}
      <Select
        value={form.frequency}
        onValueChange={(v) =>
          setForm({ ...form, frequency: v })
        }
      >
        <SelectTrigger>
          <SelectValue placeholder="Frequency" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="daily">Daily</SelectItem>
          <SelectItem value="weekdays">Weekdays</SelectItem>
          <SelectItem value="weekend">Weekend</SelectItem>
          <SelectItem value="custom">Custom</SelectItem>
        </SelectContent>
      </Select>

      <Input
        type="date"
        value={form.startDate}
        onChange={(e) =>
          setForm({ ...form, startDate: e.target.value })
        }
      />

      <Input
        type="date"
        value={form.endDate}
        onChange={(e) =>
          setForm({ ...form, endDate: e.target.value })
        }
      />

      <Button onClick={onSubmit} className="w-full">
        Create Habit
      </Button>

    </div>
  );
}