// export default function GoalPage() {
//   return <div className="p-6">Goal Page</div>;
// }

"use client";

import { useAuth } from "@/lib/auth-context";
import { useGoals } from "@/hooks/useGoals";

export default function ArchivePage() {
  const { user } = useAuth();
  const { goals } = useGoals(user?.uid || "");

  const archived = goals.filter((g) => g.status === "archived");

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-4">

      <h1 className="text-2xl font-bold">📦 Archive</h1>

      {archived.length === 0 && (
        <p className="text-muted-foreground">
          No archived goals
        </p>
      )}

      {archived.map((g) => (
        <div
          key={g.id}
          className="border rounded-xl p-4 bg-muted/30"
        >
          <p className="font-semibold">{g.name}</p>
          <p className="text-xs text-muted-foreground">
            Archived goal
          </p>
        </div>
      ))}

    </div>
  );
}