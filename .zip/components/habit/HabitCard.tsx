"use client";

import { Habit } from "@/types/habit.types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame } from "lucide-react";

export default function HabitCard({
  habit,
  onClick,
}: {
  habit: Habit;
  onClick: () => void;
}) {
  return (
    <Card
      onClick={onClick}
      className="cursor-pointer transition hover:shadow-md"
    >
      <CardContent className="flex items-center justify-between p-4">

        <div className="space-y-1">
          <p className="font-medium">{habit.name}</p>

          {habit.category && (
            <Badge variant="secondary" className="text-xs">
              {habit.category}
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-1 text-sm font-medium">
          <Flame className="w-4 h-4 text-orange-500" />
          {habit.currentStreak}
        </div>

      </CardContent>
    </Card>
  );
}