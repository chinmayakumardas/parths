"use client";

import { useEffect, useState } from "react";
import { Habit } from "@/types/habit.types";
import {
  listenHabits,
  createHabit,
  updateHabit,
  deleteHabit,
} from "@/lib/services/habit.service";

export function useHabits(uid: string) {
  const [habits, setHabits] = useState<Habit[]>([]);

  useEffect(() => {
    if (!uid) return;
    const unsub = listenHabits(uid, setHabits);
    return () => unsub();
  }, [uid]);

  return {
    habits,
    add: (h: any) => createHabit(uid, h),
    update: (id: string, data: any) => updateHabit(uid, id, data),
    remove: (id: string) => deleteHabit(uid, id),
  };
}