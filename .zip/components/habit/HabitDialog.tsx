"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import HabitForm from "./HabitForm";

export default function HabitDialog({
  open,
  setOpen,
  form,
  setForm,
  onSubmit,
}: any) {
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">

        <DialogHeader>
          <DialogTitle>Create Habit</DialogTitle>
        </DialogHeader>

        <HabitForm
          form={form}
          setForm={setForm}
          onSubmit={onSubmit}
        />

      </DialogContent>
    </Dialog>
  );
}