import { db } from "../firebase";
import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

const path = (uid: string) => `users/${uid}/goals`;

export const createGoal = (uid: string, data: any) =>
  addDoc(collection(db, path(uid)), data);

export const getGoals = async (uid: string) => {
  const snap = await getDocs(collection(db, path(uid)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

export const updateGoal = (uid: string, id: string, data: any) =>
  updateDoc(doc(db, path(uid), id), data);

export const deleteGoal = (uid: string, id: string) =>
  deleteDoc(doc(db, path(uid), id));