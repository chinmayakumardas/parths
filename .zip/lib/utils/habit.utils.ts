export const generateStreak = (
  start: string,
  end?: string
) => {
  const days = [];
  const startDate = new Date(start);
  const endDate = end ? new Date(end) : new Date();

  for (
    let d = new Date(startDate);
    d <= endDate;
    d.setDate(d.getDate() + 1)
  ) {
    days.push({
      date: d.toISOString().slice(0, 10),
      status: 0,
    });
  }

  return days;
};

export const calculateStreak = (days: any[]) => {
  let current = 0;
  let longest = 0;

  for (let i = 0; i < days.length; i++) {
    if (days[i].status === 1) {
      current++;
      longest = Math.max(longest, current);
    } else {
      current = 0;
    }
  }

  return { current, longest };
};