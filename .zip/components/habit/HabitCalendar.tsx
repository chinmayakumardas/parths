"use client";

import { Habit } from "@/types/habit.types";

export default function HabitCalendar({ habit }: { habit: Habit }) {
  return (
    <div className="grid grid-cols-7 gap-1">

      {habit.habitStreak.map((d) => (
        <div
          key={d.date}
          className={`h-5 rounded-md transition
            ${
              d.status === 1
                ? "bg-primary"
                : "bg-muted"
            }
          `}
          title={d.date}
        />
      ))}

    </div>
  );
}