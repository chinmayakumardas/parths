// export default function HabitPage() {
//   return <div className="p-6">Habit Page</div>;
// }
"use client";

import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useHabits } from "@/hooks/useHabits";
import { generateStreak } from "@/lib/utils/habit.utils";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { Plus, Flame } from "lucide-react";

export default function HabitPage() {
  const { user } = useAuth();
  const { habits, add } = useHabits(user?.uid || "");

  const [open, setOpen] = useState(false);

  const [form, setForm] = useState({
    name: "",
    category: "",
    frequency: "daily",
    startDate: "",
    endDate: "",
  });

  const create = async () => {
    const streak = generateStreak(form.startDate, form.endDate);

    await add({
      ...form,
      userId: user?.uid,
      habitStreak: streak,
      currentStreak: 0,
      longestStreak: 0,
      createdAt: new Date().toISOString(),
    });

    setOpen(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">

      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Habits</h1>

        <Button onClick={() => setOpen(true)}>
          <Plus className="w-4 h-4 mr-1" />
          New Habit
        </Button>
      </div>

      {/* LIST */}
      <div className="grid gap-4">
        {habits.map((h) => (
          <div
            key={h.id}
            className="p-4 border rounded-xl bg-background flex justify-between items-center"
          >
            <div>
              <div className="font-medium">{h.name}</div>
              <div className="text-xs text-muted-foreground">
                {h.category}
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <Flame className="w-4 h-4 text-orange-500" />
              {h.currentStreak}
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>

          <DialogHeader>
            <DialogTitle>Create Habit</DialogTitle>
          </DialogHeader>

          <div className="space-y-3">

            <Input
              placeholder="Habit name"
              onChange={(e) =>
                setForm({ ...form, name: e.target.value })
              }
            />

            <Input
              placeholder="Category"
              onChange={(e) =>
                setForm({ ...form, category: e.target.value })
              }
            />

            <Input
              type="date"
              onChange={(e) =>
                setForm({ ...form, startDate: e.target.value })
              }
            />

            <Input
              type="date"
              onChange={(e) =>
                setForm({ ...form, endDate: e.target.value })
              }
            />

            <Button onClick={create} className="w-full">
              Create
            </Button>

          </div>

        </DialogContent>
      </Dialog>

    </div>
  );
}