import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
} from "firebase/firestore";

import { db } from "@/lib/firebase";
import { Habit } from "@/types/habit.types";

const col = (uid: string) => collection(db, "users", uid, "habits");

export const listenHabits = (uid: string, cb: (h: Habit[]) => void) => {
  return onSnapshot(col(uid), (snap) => {
    const data = snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
    })) as Habit[];
    cb(data);
  });
};

export const createHabit = async (uid: string, habit: Partial<Habit>) => {
  return addDoc(col(uid), habit);
};

export const updateHabit = async (uid: string, id: string, data: Partial<Habit>) => {
  return updateDoc(doc(db, "users", uid, "habits", id), data);
};

export const deleteHabit = async (uid: string, id: string) => {
  return deleteDoc(doc(db, "users", uid, "habits", id));
};