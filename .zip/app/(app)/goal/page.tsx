// export default function GoalPage() {
//   return <div className="p-6">Goal Page</div>;
// }


// "use client";

// import { useState } from "react";
// import { useAuth } from "@/lib/auth-context";
// import { useGoals } from "@/hooks/useGoals";
// import { useMilestones } from "@/hooks/useMilestones";

// import {
//   Accordion,
//   AccordionContent,
//   AccordionItem,
//   AccordionTrigger,
// } from "@/components/ui/accordion";

// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";

// import {
//   Dialog,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
// } from "@/components/ui/dialog";

// /* ================= MAIN ================= */

// export default function GoalPage() {
//   const { user } = useAuth();

//   const {
//     goals,
//     add: addGoal,
//     update: updateGoal,
//     remove: deleteGoal,
//   } = useGoals(user?.uid || "");

//   const {
//     milestones,
//     add: addMilestone,
//     update: updateMilestone,
//     remove: deleteMilestone,
//   } = useMilestones(user?.uid || "");

//   /* ================= STATES ================= */

//   const [openGoal, setOpenGoal] = useState<string | null>(null);

//   const [goalModal, setGoalModal] = useState(false);
//   const [editGoal, setEditGoal] = useState<any>(null);

//   const [editMilestone, setEditMilestone] = useState<any>(null);

//   const [goalForm, setGoalForm] = useState({
//     name: "",
//     startDate: "",
//     endDate: "",
//   });

//   const [milestoneForm, setMilestoneForm] = useState({
//     name: "",
//   });

//   /* ================= LIMIT ================= */

//   const canAddGoal = goals.length < 5;

//   /* ================= UI ================= */

//   return (
//     <div className="p-4 max-w-3xl mx-auto space-y-6">

//       {/* ================= HEADER ================= */}
//       <div className="flex items-center justify-between">

//         <div>
//           <h1 className="text-xl font-bold">🎯 Goals</h1>
//           <p className="text-xs text-muted-foreground">
//             Max 5 goals • Execution mode
//           </p>
//         </div>

//         <Button
//           disabled={!canAddGoal}
//           onClick={() => setGoalModal(true)}
//         >
//           + Add Goal
//         </Button>

//       </div>

//       {/* ================= GOALS ================= */}
//       <Accordion
//         type="single"
//         collapsible
//         value={openGoal || ""}
//         onValueChange={(v) => setOpenGoal(v)}
//       >

//         {goals.map((g, index) => (
//           <AccordionItem key={g.id} value={g.id}>

//             <AccordionTrigger className="flex justify-between">

//               <span>
//                 {index + 1}. {g.name}
//               </span>

//             </AccordionTrigger>

//             <AccordionContent className="space-y-3">

//               {/* ACTIONS */}
//               <div className="flex gap-2">

//                 <Button
//                   size="sm"
//                   variant="outline"
//                   onClick={() => setEditGoal(g)}
//                 >
//                   Edit
//                 </Button>

//                 <Button
//                   size="sm"
//                   variant="destructive"
//                   onClick={() => deleteGoal(g.id)}
//                 >
//                   Delete
//                 </Button>

//               </div>

//               {/* MILESTONE INPUT (ENTER TO ADD) */}
//               <Input
//                 placeholder="Add milestone (press Enter)"
//                 onKeyDown={(e: any) => {
//                   if (e.key === "Enter") {
//                     if (!e.target.value) return;

//                     addMilestone({
//                       name: e.target.value,
//                       goalId: g.id,
//                       frequencyType: "daily",
//                       startDate: new Date().toISOString(),
//                     });

//                     e.target.value = "";
//                   }
//                 }}
//               />

//               {/* MILESTONES LIST */}
//               <div className="space-y-2">

//                 {milestones
//                   .filter((m: any) => m.goalId === g.id)
//                   .map((m: any) => (
//                     <div
//                       key={m.id}
//                       className="flex justify-between items-center border p-2 rounded"
//                     >

//                       <span>{m.name}</span>

//                       <div className="flex gap-2">

//                         <Button
//                           size="sm"
//                           variant="outline"
//                           onClick={() => setEditMilestone(m)}
//                         >
//                           Edit
//                         </Button>

//                         <Button
//                           size="sm"
//                           variant="destructive"
//                           onClick={() => deleteMilestone(m.id)}
//                         >
//                           Delete
//                         </Button>

//                       </div>

//                     </div>
//                   ))}

//               </div>

//             </AccordionContent>

//           </AccordionItem>
//         ))}

//       </Accordion>

//       {/* ================= CREATE GOAL MODAL ================= */}
//       <Dialog open={goalModal} onOpenChange={setGoalModal}>
//         <DialogContent>

//           <DialogHeader>
//             <DialogTitle>Create Goal</DialogTitle>
//           </DialogHeader>

//           <div className="space-y-3">

//             <Input
//               placeholder="Goal name"
//               value={goalForm.name}
//               onChange={(e) =>
//                 setGoalForm({ ...goalForm, name: e.target.value })
//               }
//             />

//             <Input
//               type="date"
//               onChange={(e) =>
//                 setGoalForm({
//                   ...goalForm,
//                   startDate: e.target.value,
//                 })
//               }
//             />

//             <Input
//               type="date"
//               onChange={(e) =>
//                 setGoalForm({
//                   ...goalForm,
//                   endDate: e.target.value,
//                 })
//               }
//             />

//             <Button
//               className="w-full"
//               onClick={() => {
//                 addGoal({
//                   name: goalForm.name,
//                   startDate: goalForm.startDate,
//                   endDate: goalForm.endDate,
//                   status: "active",
//                 });

//                 setGoalForm({
//                   name: "",
//                   startDate: "",
//                   endDate: "",
//                 });

//                 setGoalModal(false);
//               }}
//             >
//               Save Goal
//             </Button>

//           </div>

//         </DialogContent>
//       </Dialog>

//       {/* ================= EDIT GOAL MODAL ================= */}
//       <Dialog open={!!editGoal} onOpenChange={() => setEditGoal(null)}>
//         <DialogContent>

//           <DialogHeader>
//             <DialogTitle>Edit Goal</DialogTitle>
//           </DialogHeader>

//           {editGoal && (
//             <div className="space-y-3">

//               <Input
//                 defaultValue={editGoal.name}
//                 onChange={(e) =>
//                   setEditGoal({
//                     ...editGoal,
//                     name: e.target.value,
//                   })
//                 }
//               />

//               <Button
//                 className="w-full"
//                 onClick={() => {
//                   updateGoal(editGoal.id, editGoal);
//                   setEditGoal(null);
//                 }}
//               >
//                 Update
//               </Button>

//             </div>
//           )}

//         </DialogContent>
//       </Dialog>

//       {/* ================= EDIT MILESTONE MODAL ================= */}
//       <Dialog
//         open={!!editMilestone}
//         onOpenChange={() => setEditMilestone(null)}
//       >
//         <DialogContent>

//           <DialogHeader>
//             <DialogTitle>Edit Milestone</DialogTitle>
//           </DialogHeader>

//           {editMilestone && (
//             <div className="space-y-3">

//               <Input
//                 defaultValue={editMilestone.name}
//                 onChange={(e) =>
//                   setEditMilestone({
//                     ...editMilestone,
//                     name: e.target.value,
//                   })
//                 }
//               />

//               <Button
//                 className="w-full"
//                 onClick={() => {
//                   updateMilestone(editMilestone.id, editMilestone);
//                   setEditMilestone(null);
//                 }}
//               >
//                 Update
//               </Button>

//             </div>
//           )}

//         </DialogContent>
//       </Dialog>

//     </div>
//   );
// }



"use client";

import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useGoals } from "@/hooks/useGoals";
import { useMilestones } from "@/hooks/useMilestones";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  Pencil,
  Trash2,
  Flag,
  Calendar,
  Activity,
} from "lucide-react";

export default function GoalPage() {
  const { user } = useAuth();

  const {
    goals,
    add: addGoal,
    update: updateGoal,
    remove: deleteGoal,
  } = useGoals(user?.uid || "");

  const {
    milestones,
    add: addMilestone,
    update: updateMilestone,
    remove: deleteMilestone,
  } = useMilestones(user?.uid || "");

  const [editGoal, setEditGoal] = useState<any>(null);
  const [editMilestone, setEditMilestone] = useState<any>(null);
  const [goalModal, setGoalModal] = useState(false);

  const [goalForm, setGoalForm] = useState({
    name: "",
    startDate: "",
    endDate: "",
  });

  const canAddGoal = goals.length < 5;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">

      {/* ================= HEADER ================= */}
      <div className="flex justify-between items-end">

        <div>
          <h1 className="text-3xl font-bold">🎯 Goals</h1>
          <p className="text-sm text-muted-foreground">
            Execution mode • Max 5 active goals
          </p>
        </div>

        <Button disabled={!canAddGoal} onClick={() => setGoalModal(true)}>
          + New Goal
        </Button>

      </div>

      {/* ================= GOAL GRID ================= */}
      <div className="grid gap-5">

        {goals.map((g, i) => (
          <div
            key={g.id}
            className="group border rounded-2xl bg-background hover:shadow-lg transition overflow-hidden"
          >

            {/* ================= GOAL HEADER ================= */}
            <div className="flex justify-between items-center p-5 bg-muted/30">

              <div className="flex flex-col">

                <span className="text-lg font-semibold flex items-center gap-2">
                  <Flag className="w-4 h-4" />
                  {i + 1}. {g.name}
                </span>

                <span className="text-xs text-muted-foreground flex items-center gap-2 mt-1">
                  <Calendar className="w-3 h-3" />
                  {g.startDate || "—"} → {g.endDate || "—"}
                </span>

              </div>

              {/* HOVER ACTIONS */}
              <div className="opacity-0 group-hover:opacity-100 transition flex gap-2">

                <Button
                  size="icon"
                  variant="outline"
                  onClick={() => setEditGoal(g)}
                >
                  <Pencil className="w-4 h-4" />
                </Button>

                <Button
                  size="icon"
                  variant="destructive"
                  onClick={() => deleteGoal(g.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>

              </div>

            </div>

            {/* ================= ADD MILESTONE ================= */}
            <div className="p-5 space-y-4">

              <Input
                placeholder="➕ Add milestone & press Enter"
                className="h-11"
                onKeyDown={(e: any) => {
                  if (e.key === "Enter" && e.target.value) {
                    addMilestone({
                      name: e.target.value,
                      goalId: g.id,
                      frequencyType: "daily",
                      startDate: new Date().toISOString(),
                    });

                    e.target.value = "";
                  }
                }}
              />

              {/* ================= MILESTONES ================= */}
              <div className="space-y-3">

                {milestones
                  .filter((m: any) => m.goalId === g.id)
                  .map((m: any) => (
                    <div
                      key={m.id}
                      className="group flex justify-between items-center p-4 rounded-xl border bg-muted/20 hover:bg-muted transition"
                    >

                      {/* LEFT */}
                      <div className="flex flex-col">

                        <span className="font-medium flex items-center gap-2">
                          <Activity className="w-4 h-4" />
                          {m.name}
                        </span>

                        <span className="text-xs text-muted-foreground">
                          Frequency: {m.frequencyType}
                        </span>

                      </div>

                      {/* RIGHT ACTIONS */}
                      <div className="opacity-0 group-hover:opacity-100 transition flex gap-2">

                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => setEditMilestone(m)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>

                        <Button
                          size="icon"
                          variant="destructive"
                          onClick={() => deleteMilestone(m.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>

                      </div>

                    </div>
                  ))}

              </div>

            </div>

          </div>
        ))}

      </div>

      {/* ================= CREATE GOAL ================= */}
      <Dialog open={goalModal} onOpenChange={setGoalModal}>
        <DialogContent>

          <DialogHeader>
            <DialogTitle>Create Goal</DialogTitle>
          </DialogHeader>

          <div className="space-y-3">

            <Input
              placeholder="Goal name"
              onChange={(e) =>
                setGoalForm({ ...goalForm, name: e.target.value })
              }
            />

            <Input
              type="date"
              onChange={(e) =>
                setGoalForm({ ...goalForm, startDate: e.target.value })
              }
            />

            <Input
              type="date"
              onChange={(e) =>
                setGoalForm({ ...goalForm, endDate: e.target.value })
              }
            />

            <Button
              className="w-full"
              onClick={() => {
                addGoal({
                  ...goalForm,
                  status: "active",
                });

                setGoalModal(false);
              }}
            >
              Create Goal
            </Button>

          </div>

        </DialogContent>
      </Dialog>

      {/* ================= EDIT GOAL ================= */}
      <Dialog open={!!editGoal} onOpenChange={() => setEditGoal(null)}>
        <DialogContent>

          <DialogHeader>
            <DialogTitle>Edit Goal</DialogTitle>
          </DialogHeader>

          {editGoal && (
            <div className="space-y-3">

              <Input
                defaultValue={editGoal.name}
                onChange={(e) =>
                  setEditGoal({ ...editGoal, name: e.target.value })
                }
              />

              <Button
                className="w-full"
                onClick={() => {
                  updateGoal(editGoal.id, editGoal);
                  setEditGoal(null);
                }}
              >
                Save
              </Button>

            </div>
          )}

        </DialogContent>
      </Dialog>

    </div>
  );
}