"use client";

import { useEffect, useState } from "react";
import {
  createGoal,
  getGoals,
  updateGoal,
  deleteGoal,
} from "@/lib/services/goal.service";

export const useGoals = (uid: string) => {
  const [goals, setGoals] = useState<any[]>([]);

  const fetchGoals = async () => {
    if (!uid) return;
    const data = await getGoals(uid);
    setGoals(data);
  };

  const add = async (data: any) => {
    await createGoal(uid, data);
    fetchGoals();
  };

  const update = async (id: string, data: any) => {
    await updateGoal(uid, id, data);
    fetchGoals();
  };

  const remove = async (id: string) => {
    await deleteGoal(uid, id);
    fetchGoals();
  };

  useEffect(() => {
    fetchGoals();
  }, [uid]);

  return {
    goals,
    add,
    update,
    remove,
  };
};