import { useEffect, useState } from "react";
import {
  createMilestone,
  getMilestonesByGoal,
  updateMilestone,
  deleteMilestone,
} from "@/lib/services/milestone.service";

export const useMilestones = (uid: string, goalId: string) => {
  const [milestones, setMilestones] = useState<any[]>([]);

  /* LOAD */
  useEffect(() => {
    if (!uid || !goalId) return;

    const load = async () => {
      const data = await getMilestonesByGoal(uid, goalId);
      setMilestones(data);
    };

    load();
  }, [uid, goalId]);

  /* ADD */
  const add = async (data: any) => {
    if (!uid) return;

    await createMilestone(uid, {
      ...data,
      goalId, // 🔥 THIS IS CRITICAL
    });

    const updated = await getMilestonesByGoal(uid, goalId);
    setMilestones(updated);
  };

  /* UPDATE */
  const update = async (id: string, data: any) => {
    await updateMilestone(uid, id, data);

    const updated = await getMilestonesByGoal(uid, goalId);
    setMilestones(updated);
  };

  /* DELETE */
  const remove = async (id: string) => {
    await deleteMilestone(uid, id);

    const updated = await getMilestonesByGoal(uid, goalId);
    setMilestones(updated);
  };

  return { milestones, add, update, remove };
};